# Практическое занятие 5  
**Создание и анимация нестандартных кнопок, работа с радиокнопками и чекбоксами, а также генерация и графическое отображение случайных чисел с управлением их количеством и диапазоном**  

---

## 📌 Основные задания (обязательные)

Выполните в **одном проекте** следующие задачи:

1. **Термометр**  
   <img width="907" height="468" alt="image" src="https://github.com/user-attachments/assets/8e7eff78-cd12-4ed3-ba80-f4cff559b9b0" />

2. **Градусник**  
   <img width="279" height="306" alt="image" src="https://github.com/user-attachments/assets/9a4e5e77-de0e-4595-b1e2-2846580dbaa9" />

3. **Часы**  
   <img width="582" height="297" alt="image" src="https://github.com/user-attachments/assets/1c3c6acd-daa2-46ba-b3e0-3e5bad8b1b5a" />

4. **Заряд батареи**  
   <img width="854" height="329" alt="image" src="https://github.com/user-attachments/assets/8886e9b5-7ccc-4a3d-8cab-94d972caa631" />
   
5. **Спидометр**  
   <img width="671" height="352" alt="image" src="https://github.com/user-attachments/assets/4aab59d3-2a47-40dd-ab69-e2bfdc53dda8" />

6. **Звуковой микшер**  
   <img width="686" height="157" alt="image" src="https://github.com/user-attachments/assets/89af51ce-f352-4007-968a-9b6428041656" />

  
7. **Авиагоризонт**  
   <img width="970" height="251" alt="image" src="https://github.com/user-attachments/assets/4f86b2bd-4eee-42b2-b73c-db60685edb43" />

9. **Индикаторы направления**  
   <img width="1200" height="251" alt="image" src="https://github.com/user-attachments/assets/72e333ec-b873-42c1-8f5b-46b0e2b2650e" />

10. **Анимация уровня жидкостей**
   <img width="1198" height="243" alt="image" src="https://github.com/user-attachments/assets/480b370e-0c10-4eb6-ad62-8bccc652e100" />

11. **Компас**
   <img width="213" height="222" alt="image" src="https://github.com/user-attachments/assets/39db7845-a92c-4a7d-a922-5358a34f536b" />

12. **Многооконный Интерфейс - кассетный магнитофон. Сотворить по библиотеке наиболее легендарных и стильных кассет, анимировать катушки кассеты(https://4pda.to/forum/index.php?showtopic=696111)**
   <img width="1189" height="372" alt="image" src="https://github.com/user-attachments/assets/84342d2b-28a5-4ae5-98b0-32846d1b8f5d" />

13. **Интерфейс инструмента генератор анимировать все по макс.(цифры, кнопки, крутилки, и т.п)**
   <img width="919" height="610" alt="image" src="https://github.com/user-attachments/assets/91aece8a-31ad-49f4-ab03-46d4e0912e1c" />

> 💡 Дизайн должен быть **аккуратным**: выравнивание, подписи к компонентам, отступы.

---

## 📁 Структура проекта

- Форма должна быть **понятной и удобной** — не «куча компонентов в углу».
- Используйте `TPanel`, `TGroupBox`, подписи (`Caption`) для группировки.

---

## 📤 Сдача работы

1. Загрузите **весь проект** в репозиторий:
   - `.lpi`, `.lpr`, `.lfm`, `.pas` и другие файлы проекта.
2. Убедитесь, что проект **компилируется и запускается**.
3. Сделайте **несколько осмысленных коммитов**.

> ⚠️ Последний коммит — до дедлайна.  
> Работы без индивидуального имени — **0 баллов**.

---

## 🛑 Запрещено

- Использовать чужие проекты без изменений.
- Копировать код из интернета без понимания.
- Использовать изображения с котиками, мемами, логотипами.

---

Удачи! Помните: цель — **научиться управлять компонентами**, а не просто «сдать».
